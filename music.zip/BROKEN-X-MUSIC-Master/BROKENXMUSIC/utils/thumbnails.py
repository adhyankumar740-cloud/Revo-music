import os
import re
import aiofiles
import aiohttp
from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps
from unidecode import unidecode
from youtube_search import YoutubeSearch
from BROKENXMUSIC import app
from config import YOUTUBE_IMG_URL

def changeImageSize(maxWidth, maxHeight, image):
    widthRatio = maxWidth / image.size[0]
    heightRatio = maxHeight / image.size[1]
    newWidth = int(widthRatio * image.size[0])
    newHeight = int(heightRatio * image.size[1])
    newImage = image.resize((newWidth, newHeight))
    return newImage

def truncate(text):
    list = text.split(" ")
    text1 = ""
    text2 = ""    
    for i in list:
        if len(text1) + len(i) < 30:        
            text1 += " " + i
        elif len(text2) + len(i) < 30:       
            text2 += " " + i

    text1 = text1.strip()
    text2 = text2.strip()     
    return [text1,text2]

def crop_center_circle(img, output_size, border, crop_scale=1.5):
    half_the_width = img.size[0] / 2
    half_the_height = img.size[1] / 2
    larger_size = int(output_size * crop_scale)
    img = img.crop(
        (
            half_the_width - larger_size/2,
            half_the_height - larger_size/2,
            half_the_width + larger_size/2,
            half_the_height + larger_size/2
        )
    )
    
    img = img.resize((output_size - 2*border, output_size - 2*border))
    
    final_img = Image.new("RGBA", (output_size, output_size), "white")
    
    mask_main = Image.new("L", (output_size - 2*border, output_size - 2*border), 0)
    draw_main = ImageDraw.Draw(mask_main)
    draw_main.ellipse((0, 0, output_size - 2*border, output_size - 2*border), fill=255)
    
    final_img.paste(img, (border, border), mask_main)
    
    mask_border = Image.new("L", (output_size, output_size), 0)
    draw_border = ImageDraw.Draw(mask_border)
    draw_border.ellipse((0, 0, output_size, output_size), fill=255)
    
    result = Image.composite(final_img, Image.new("RGBA", final_img.size, (0, 0, 0, 0)), mask_border)
    return result


async def get_thumb(videoid):
    if os.path.isfile(f"cache/{videoid}_v4.png"):
        return f"cache/{videoid}_v4.png"

    url = f"https://www.youtube.com/watch?v={videoid}"
    
    try:
        results = YoutubeSearch(url, max_results=1).to_dict()
        if results:
            result = results[0]
            
            title = result.get("title", "Unsupported Title")
            title = re.sub("\W+", " ", title)
            title = title.title()
            
            duration = result.get("duration", "Unknown Mins")
            
            thumbs = result.get("thumbnails", [])
            if isinstance(thumbs, list) and len(thumbs) > 0:
                thumbnail = thumbs[0].split("?")[0]
            elif isinstance(thumbs, str):
                thumbnail = thumbs
            else:
                thumbnail = YOUTUBE_IMG_URL

            views = result.get("views", "Unknown Views")
            channel = result.get("channel", "Unknown Channel")
        else:
            raise Exception("No results found")
            
    except Exception as e:
        print(f"Error generating thumbnail info: {e}")
        title = "Unknown Title"
        duration = "00:00"
        thumbnail = YOUTUBE_IMG_URL
        views = "Unknown Views"
        channel = "Unknown Channel"

    async with aiohttp.ClientSession() as session:
        async with session.get(thumbnail) as resp:
            if resp.status == 200:
                f = await aiofiles.open(f"cache/thumb{videoid}.png", mode="wb")
                await f.write(await resp.read())
                await f.close()

    try:
        
        youtube = Image.open(f"cache/thumb{videoid}.png")
        image1 = changeImageSize(1280, 720, youtube)
        image2 = image1.convert("RGBA")
        
        background = image2.filter(filter=ImageFilter.BoxBlur(20))
        enhancer = ImageEnhance.Brightness(background)
        background = enhancer.enhance(0.6)
        
        
        try:
            wm_text = "Powered By Broken X Network"
            
            wm_font = ImageFont.truetype("BROKENXMUSIC/assets/font.ttf", 20)
            
            
            wm_layer = Image.new('RGBA', background.size, (255, 255, 255, 0))
            wm_draw = ImageDraw.Draw(wm_layer)
            
            try:
                wm_len = wm_draw.textlength(wm_text, font=wm_font)
            except:
                wm_len = 300 
            
            
            wm_draw.text((1280 - wm_len - 30, 30), wm_text, fill=(255, 255, 255, 150), font=wm_font)
            
            
            background = Image.alpha_composite(background, wm_layer)
            
        except Exception as wm_e:
            print(f"Watermark Error: {wm_e}")
        

        
        draw = ImageDraw.Draw(background)
        
        arial = ImageFont.truetype("BROKENXMUSIC/assets/font2.ttf", 30)
        font = ImageFont.truetype("BROKENXMUSIC/assets/font.ttf", 30)
        title_font = ImageFont.truetype("BROKENXMUSIC/assets/font3.ttf", 45)

        circle_thumbnail = crop_center_circle(youtube, 400, 20)
        circle_thumbnail = circle_thumbnail.resize((400, 400))
        circle_position = (120, 160)
        background.paste(circle_thumbnail, circle_position, circle_thumbnail)

        text_x_position = 565

        title1 = truncate(title)
        draw.text((text_x_position, 180), title1[0], fill=(255, 255, 255), font=title_font)
        draw.text((text_x_position, 230), title1[1], fill=(255, 255, 255), font=title_font)
        draw.text((text_x_position, 320), f"{channel}  |  {views[:23]}", (255, 255, 255), font=arial)

        line_length = 580  
        red_length = int(line_length * 0.6)
        white_length = line_length - red_length

        start_point_red = (text_x_position, 380)
        end_point_red = (text_x_position + red_length, 380)
        draw.line([start_point_red, end_point_red], fill="red", width=9)

        start_point_white = (text_x_position + red_length, 380)
        end_point_white = (text_x_position + line_length, 380)
        draw.line([start_point_white, end_point_white], fill="white", width=8)

        circle_radius = 10 
        circle_position = (end_point_red[0], end_point_red[1])
        draw.ellipse([circle_position[0] - circle_radius, circle_position[1] - circle_radius,
                    circle_position[0] + circle_radius, circle_position[1] + circle_radius], fill="red")
        
        draw.text((text_x_position, 400), "00:00", (255, 255, 255), font=arial)
        draw.text((1080, 400), duration, (255, 255, 255), font=arial)

        try:
            play_icons = Image.open("BROKENXMUSIC/assets/play_icons.png")
            play_icons = play_icons.resize((580, 62))
            background.paste(play_icons, (text_x_position, 450), play_icons)
        except Exception as e:
            print(f"Icon Error: {e}")

        try:
            os.remove(f"cache/thumb{videoid}.png")
        except:
            pass
            
        background.save(f"cache/{videoid}_v4.png")
        return f"cache/{videoid}_v4.png"
        
    except Exception as e:
        print(f"Error creating thumbnail: {e}")
        return YOUTUBE_IMG_URL
